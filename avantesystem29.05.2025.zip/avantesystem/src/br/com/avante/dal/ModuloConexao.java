/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.avante.dal;

import java.sql.*;

/**
 *
 * @author lucas
 */
public class ModuloConexao {
    //método responsvel por estabelecer a conexão com o banco
    public static Connection conector() {
        java.sql.Connection conexao = null;
        // a linha abaixo "chama" o driver
        String driver = "com.mysql.cj.jdbc.Driver";
        //armazenando informações referente ao banco
        //String url="jdbc:mysql://localhost:3306/dbinfox";
        // **** ALTERAÇÕES AQUI ****
        String url="jdbc:mysql://ads-aula.mysql.uhserver.com:3306/ads_aula"; // Altere "SEU_NOME_DO_BANCO_DE_DADOS"
        String user = "alunoads2025";
        String password = "@AdS20251"; // Você precisará da senha para o usuário 'alunoads2025'
        
        //Estabelecendo Conexão com o banco
        
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            // a linha abaixo serve de apoio ao status de conexão
            //System.out.println(e);
            return null;
        
        }
    }
}
