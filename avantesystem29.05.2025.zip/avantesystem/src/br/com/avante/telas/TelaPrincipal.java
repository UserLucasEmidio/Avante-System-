/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.avante.telas;

import static java.awt.SystemColor.desktop;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import br.com.avante.Estilizacao.Estilizacao;
import java.awt.Color; // Import para usar a cor diretamente
import java.awt.Font;
import javax.swing.JFrame;


/**
 *
 * @author lucas
 */
public class TelaPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form TelaPrincipal
     */
    public TelaPrincipal() {
        initComponents();
        
        exibirDataAtual();
        openCadastroScreen();
        
        // --- INÍCIO DA ALTERAÇÃO AQUI (no construtor sem parâmetros) ---
    Responsaveis telaResponsaveis = new Responsaveis(); // Instancia a tela Responsaveis
    telaResponsaveis.setVisible(true); // Torna a tela Responsaveis visível
    // Define o comportamento de fechamento para DISPOSE_ON_CLOSE,
    // o que significa que apenas esta janela será fechada e liberada da memória.
    telaResponsaveis.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
    // --- FIM DA ALTERAÇÃO AQUI ---
        
        aplicarEstilos();
                menAvancados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirFuncionarioHistorico();
            }
        });
    }
    
    private void aplicarEstilos() {
        Color corPrimaria = new Color(0, 50, 0);  // Verde bem escuro (R, G, B)
        Font fonteNegrito = new Font("Segoe UI", Font.BOLD, 12); // Use a mesma fonte e tamanho do original, mas em negrito

        // Estilizar os JMenus que começam com "btn"
        if (btnAgenda != null) {
            btnAgenda.setForeground(corPrimaria);
            btnAgenda.setFont(fonteNegrito);
        }
        if (btnCadastro != null) {
            btnCadastro.setForeground(corPrimaria);
            btnCadastro.setFont(fonteNegrito);
        }
        if (btnConsulta != null) {
            btnConsulta.setForeground(corPrimaria);
            btnConsulta.setFont(fonteNegrito);
        }
        if (btnContato != null) {
            btnContato.setForeground(corPrimaria);
            btnContato.setFont(fonteNegrito);
        }
        if (btnOption != null) {
            btnOption.setForeground(corPrimaria);
            btnOption.setFont(fonteNegrito);
        }
        
        // Estilizar os JMenuItems que começam com "men"
        if (menAgenda != null) {
            menAgenda.setForeground(corPrimaria);
            menAgenda.setFont(fonteNegrito);
        }
        if (menAvancados != null) {
            menAvancados.setForeground(corPrimaria);
            menAvancados.setFont(fonteNegrito);
        }
        if (menCadastro != null) {
            menCadastro.setForeground(corPrimaria);
            menCadastro.setFont(fonteNegrito);
        }
        if (menConsulta != null) {
            menConsulta.setForeground(corPrimaria);
            menConsulta.setFont(fonteNegrito);
        }
        if (menContato != null) {
            menContato.setForeground(corPrimaria);
            menContato.setFont(fonteNegrito);
        }
        if (menSair != null) {
            menSair.setForeground(corPrimaria);
            menSair.setFont(fonteNegrito);
        }
        

        
     // Estilizar o JDesktopPane
     if (jDesktopPane1 != null) {
         jDesktopPane1.setBackground(Estilizacao.COR_DE_FUNDO); // Definir a cor de fundo
     }
    }
    
    // Novo construtor que recebe o nome do usuário
public TelaPrincipal(String nomeUsuario) {
    initComponents();
    jLabel2.setText(nomeUsuario.toUpperCase()); // Define o texto da jLabel2 com o nome do usuário (em maiúsculo, por exemplo)
    exibirDataAtual();
    openCadastroScreen();
    
        // --- INÍCIO DA ALTERAÇÃO AQUI (no construtor com parâmetro) ---
    Responsaveis telaResponsaveis = new Responsaveis(); // Instancia a tela Responsaveis
    telaResponsaveis.setVisible(true); // Torna a tela Responsaveis visível
    // Define o comportamento de fechamento para DISPOSE_ON_CLOSE.
    telaResponsaveis.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    // --- FIM DA ALTERAÇÃO AQUI ---
    aplicarEstilos();
    
    // Verifica se o nome do usuário é "LUCAS EMIDIO" (ou outra variação) e habilita o menu avançado
    if (nomeUsuario.trim().equalsIgnoreCase("LUCAS EMIDIO")) {
        menAvancados.setEnabled(true);
    } else {
        menAvancados.setEnabled(false); // Garante que o menu esteja desabilitado para outros usuários
        btnOption.remove(menAvancados);
        jMenuBar1.revalidate(); // Atualiza a barra de menu
        jMenuBar1.repaint();    // Redesenha a barra de menu
    }
    
    // Adiciona um listener para o evento de fechamento da janela
      this.addWindowListener(new java.awt.event.WindowAdapter() {
    @Override
    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
        int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Atenção", JOptionPane.YES_NO_OPTION);
        if (sair != JOptionPane.YES_OPTION) {
            // Tentar cancelar o evento de fechamento (pode não funcionar perfeitamente em todos os casos)
            setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
            return;
        }
        System.exit(0);
    }
});
} 



private void exibirDataAtual() {
        Date data = new Date(); // Obtém a data e hora atuais
        SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy"); // Define o formato da data
        jLabel1.setText(formatador.format(data)); // Define o texto da jLabel1 com a data formatada
    }

    private void openCadastroScreen() {
    // Verifica se a tela de cadastro já está aberta
    for (javax.swing.JInternalFrame frame : jDesktopPane1.getAllFrames()) {
        if (frame instanceof TelaCadastro) {
            frame.toFront(); // Se já estiver aberta, traz para frente
            return; // Sai do método
        }
    }
// Se a tela de cadastro não está aberta, cria uma nova instância
    TelaCadastro telaCadastro = new TelaCadastro();
    jDesktopPane1.add(telaCadastro); // Adiciona a nova tela ao JDesktopPane
    telaCadastro.setVisible(true); // Torna a tela visível
    try {
        telaCadastro.setSelected(true); // Foca na tela de cadastro
    } catch (java.beans.PropertyVetoException e) {
        e.printStackTrace(); // Trate a exceção conforme necessário
    }
}
    
    private void confirmarSaida() {
    int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Atenção", JOptionPane.YES_NO_OPTION);
    if (sair == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
}
    
        private void abrirFuncionarioHistorico() {
       System.out.println("Método abrirFuncionarioHistorico() foi chamado!");
        Funcionario_Historico telaHistorico = new Funcionario_Historico();
        telaHistorico.setVisible(true);
    }
        
        
 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        labelAvanteClick = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnCadastro = new javax.swing.JMenu();
        menCadastro = new javax.swing.JMenuItem();
        btnConsulta = new javax.swing.JMenu();
        menConsulta = new javax.swing.JMenuItem();
        btnContato = new javax.swing.JMenu();
        menContato = new javax.swing.JMenuItem();
        btnAgenda = new javax.swing.JMenu();
        menAgenda = new javax.swing.JMenuItem();
        btnOption = new javax.swing.JMenu();
        menAvancados = new javax.swing.JMenuItem();
        menSair = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Avante System");
        setResizable(false);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 474, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("DATA");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("FUNCIONÁRIO LOGADO");

        labelAvanteClick.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelAvanteClick.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/AvantePrincipal.png"))); // NOI18N

        btnCadastro.setText("Cadastro");
        btnCadastro.setRequestFocusEnabled(false);
        btnCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastroActionPerformed(evt);
            }
        });

        menCadastro.setText("Cadastro do Usuário");
        menCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menCadastroActionPerformed(evt);
            }
        });
        btnCadastro.add(menCadastro);

        jMenuBar1.add(btnCadastro);

        btnConsulta.setText("Consulta");

        menConsulta.setText("Consulta do Usuário");
        menConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menConsultaActionPerformed(evt);
            }
        });
        btnConsulta.add(menConsulta);

        jMenuBar1.add(btnConsulta);

        btnContato.setText("Contato");

        menContato.setText("Contato");
        menContato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menContatoActionPerformed(evt);
            }
        });
        btnContato.add(menContato);

        jMenuBar1.add(btnContato);

        btnAgenda.setText("Agenda");

        menAgenda.setText("Calendário");
        menAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menAgendaActionPerformed(evt);
            }
        });
        btnAgenda.add(menAgenda);

        jMenuBar1.add(btnAgenda);

        btnOption.setText("Opções");

        menAvancados.setText("Controle de Funcionario");
        menAvancados.setEnabled(false);
        menAvancados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menAvancadosActionPerformed(evt);
            }
        });
        btnOption.add(menAvancados);

        menSair.setText("Sair");
        menSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menSairActionPerformed(evt);
            }
        });
        btnOption.add(menSair);

        jMenuBar1.add(btnOption);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(labelAvanteClick)
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addContainerGap(110, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jDesktopPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2))
                    .addComponent(labelAvanteClick))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(196, 196, 196))
        );

        setSize(new java.awt.Dimension(1053, 693));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menAgendaActionPerformed
        //
        openFrame(TelaAgenda.class);
    }//GEN-LAST:event_menAgendaActionPerformed

    private void menContatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menContatoActionPerformed
        //
        openFrame(TelaContato.class);
    }//GEN-LAST:event_menContatoActionPerformed

    private void menConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menConsultaActionPerformed
        // TODO add your handling code here:
        openFrame(TelaConsulta.class);
    }//GEN-LAST:event_menConsultaActionPerformed

    private void btnCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastroActionPerformed
        // chamando método cadastro
        openFrame(TelaCadastro.class);
    }//GEN-LAST:event_btnCadastroActionPerformed

    private void menCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menCadastroActionPerformed
        // Verifica se a tela de cadastro já está aberta
        openFrame(TelaCadastro.class);
    }//GEN-LAST:event_menCadastroActionPerformed

    private void menSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menSairActionPerformed
        confirmarSaida();
    }//GEN-LAST:event_menSairActionPerformed

    private void menAvancadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menAvancadosActionPerformed
        abrirFuncionarioHistorico();
    }//GEN-LAST:event_menAvancadosActionPerformed
    
    
    private void openFrame(Class<?> frameClass) {
    try {
        for (javax.swing.JInternalFrame frame : jDesktopPane1.getAllFrames()) {
            if (frame.getClass().equals(frameClass)) {
                frame.toFront();
                return;
            }
        }
        javax.swing.JInternalFrame newFrame = null;
        if (frameClass.equals(TelaAgenda.class)) {
            // Passa o nome do usuário logado para o construtor da TelaAgenda
            newFrame = new TelaAgenda(jLabel2.getText());
        } else {
            newFrame = (javax.swing.JInternalFrame) frameClass.getDeclaredConstructor().newInstance();
        }
        jDesktopPane1.add(newFrame);
        newFrame.setVisible(true);
        newFrame.setSelected(true);
    } catch (Exception e) {
        e.printStackTrace();
    }
    }
    /**
     * @param args the command line arguments
     */
   public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPrincipal().setVisible(true);
                
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnAgenda;
    private javax.swing.JMenu btnCadastro;
    private javax.swing.JMenu btnConsulta;
    private javax.swing.JMenu btnContato;
    private javax.swing.JMenu btnOption;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JLabel labelAvanteClick;
    private javax.swing.JMenuItem menAgenda;
    private javax.swing.JMenuItem menAvancados;
    private javax.swing.JMenuItem menCadastro;
    private javax.swing.JMenuItem menConsulta;
    private javax.swing.JMenuItem menContato;
    private javax.swing.JMenuItem menSair;
    // End of variables declaration//GEN-END:variables
}
