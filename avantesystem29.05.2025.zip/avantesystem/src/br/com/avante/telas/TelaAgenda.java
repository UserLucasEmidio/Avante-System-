/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package br.com.avante.telas;
import br.com.avante.dal.ModuloConexao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import br.com.avante.Estilizacao.Estilizacao; // Importe a classe Estilizacao
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author lucas
 */


public class TelaAgenda extends javax.swing.JInternalFrame {
    private List<String> listaNomesUsuarios;
    private DefaultTableModel tableModel;
    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private String usuarioLogado; // Adicione esta variável
    /**
     * Creates new form TelaAgenda
     */
    public TelaAgenda() {
        initComponents();
        conexao = ModuloConexao.conector();
        inicializarTabela();
        carregarDados();
        implementarAutocompletar();
        aplicarEstilos(); // Chame aplicarEstilos aqui
        configurarGridBagLayout(); // Chama o método para configurar o layout
        
        // Adicione este bloco de código aqui:
        SwingUtilities.invokeLater(() -> {
            if (getParent() != null) {
                getParent().revalidate();
                getParent().repaint();
            }
            revalidate();
            repaint();
        });
    
    }
    
        // Novo construtor que recebe o nome do usuário logado
    public TelaAgenda(String usuario) {
        this.usuarioLogado = usuario; // Inicializa a variável com o nome do usuário
        initComponents();
        conexao = ModuloConexao.conector();
        inicializarTabela();
        carregarDados();
        implementarAutocompletar();
        aplicarEstilos(); // Chame aplicarEstilos aqui
        // Agora você tem o nome do usuário logado disponível nesta tela
        configurarGridBagLayout(); // Chama o método para configurar o layout
        System.out.println("Usuário logado na TelaAgenda: " + this.usuarioLogado);
    }
    
        private void aplicarEstilos() {
        Estilizacao.estilizarLabelTitulo(jLabel1); // Calendario
        Estilizacao.estilizarLabelPadrao(jLabel2); // Nome

        Estilizacao.estilizarTextFieldPadrao(txtNomeAg);
        Estilizacao.estilizarBotaoPadrao(btnColocarAg);
        Estilizacao.estilizarBotaoPadrao(btnLiberarAg);

        Estilizacao.estilizarTabelaPadrao(jTable1);
        Estilizacao.estilizarScrollPane(jScrollPane1);

        this.getContentPane().setBackground(Estilizacao.COR_DE_FUNDO);
    }
        
private void configurarGridBagLayout() {
    getContentPane().setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.fill = GridBagConstraints.BOTH;
    gbc.weighty = 0.0; // Peso vertical inicial padrão

    // 1. Label "Calendario"
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.anchor = GridBagConstraints.CENTER;
    add(jLabel1, gbc);

    // 2. ScrollPane da Tabela
    gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 6; // Ocupa as colunas de 0 a 5 (Horário + 5 dias)
    gbc.weighty = 1.0; // Permite expansão vertical
    gbc.weightx = 0.5; // Reduzimos o peso horizontal para 40% (aproximadamente)
    gbc.fill = GridBagConstraints.BOTH;
    add(jScrollPane1, gbc);

    // 3. Label "Nome"
    gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.weighty = 0.0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.anchor = GridBagConstraints.WEST;
    add(jLabel2, gbc);

    // 4. TextField Nome
    gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    add(txtNomeAg, gbc);

    // 5. Painel para os botões abaixo do TextField
    JPanel panelBotoes = new JPanel(new GridLayout(1, 2, 5, 0));
    panelBotoes.add(btnColocarAg);
    panelBotoes.add(btnLiberarAg);

    gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    add(panelBotoes, gbc);

    // 6. Label "jLabel3"
    gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.gridx = 6;
    gbc.gridy = 1;
    gbc.gridwidth = 1;
    gbc.weightx = 0.3; // Damos um peso para o jLabel3 ocupar o restante (aproximadamente 30%)
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.BOTH; // Preenche ambos os sentidos para evitar espaços vazios
    gbc.anchor = GridBagConstraints.WEST;
    add(jLabel3, gbc);

    pack();
}
    
    private void inicializarTabela() {
        tableModel = new DefaultTableModel(
                new Object[]{"Horário", "Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tornar todas as células não editáveis
            }
        };
        jTable1.setModel(tableModel);
        jTable1.setCellSelectionEnabled(false); // Desabilita a seleção de células
        // Adiciona os horários base na tabela (sem segundos para consistência com a comparação)
        String[] timeSlots = {"08:00", "09:00", "10:00", "11:00", "12:00",
                            "14:00", "15:00", "16:00", "17:00"};
        for (String slot : timeSlots) {
            tableModel.addRow(new Object[]{slot, "", "", "", "", ""});
        }
        
        // Ajustar automaticamente o tamanho das colunas ao conteúdo
        ajustarTamanhoColunas();
        
        // *** ADICIONE ESTA LINHA PARA EXPANDIR AS COLUNAS ***
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    }
    
    private void ajustarTamanhoColunas() {
    TableColumnModel columnModel = jTable1.getColumnModel();
    for (int column = 0; column < jTable1.getColumnCount(); column++) {
        int width = 15; // Largura mínima para o cabeçalho
        TableColumn tableColumn = columnModel.getColumn(column);
        // Obter a largura ideal para o cabeçalho
        JLabel label = new JLabel(tableColumn.getHeaderValue().toString());
        FontMetrics fm = label.getFontMetrics(label.getFont());
        width = Math.max(width, fm.stringWidth(tableColumn.getHeaderValue().toString()) + 20); // Adiciona um pequeno padding

        // Obter a largura ideal para cada célula da coluna
        for (int row = 0; row < jTable1.getRowCount(); row++) {
            Object value = jTable1.getValueAt(row, column);
            if (value != null) {
                JLabel rendererLabel = (JLabel) jTable1.getDefaultRenderer(value.getClass()).getTableCellRendererComponent(jTable1, value, false, false, row, column);
                FontMetrics fmCell = rendererLabel.getFontMetrics(rendererLabel.getFont());
                width = Math.max(width, fmCell.stringWidth(value.toString()) + 20); // Adiciona um pequeno padding
            }
        }
        tableColumn.setPreferredWidth(width);
    }
}
    
    private void carregarDados() {
        carregarNomesUsuarios();
        carregarAgendamentos();
    }
    
       private void carregarNomesUsuarios() {
        listaNomesUsuarios = new ArrayList<>();
        String sql = "SELECT nome FROM cad_usuarios";
        try (PreparedStatement pstNomes = conexao.prepareStatement(sql);
             ResultSet rsNomes = pstNomes.executeQuery()) {
            while (rsNomes.next()) {
                listaNomesUsuarios.add(rsNomes.getString("nome"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar nomes de usuários: " + e.getMessage());
        }
    }
       
       
public void carregarAgendamentos() {
    tableModel.setRowCount(0); // Limpa a tabela antes de carregar

    // Adiciona novamente os horários base (importante se a tabela foi limpa)
    String[] timeSlots = {"08:00", "09:00", "10:00", "11:00", "12:00",
                            "14:00", "15:00", "16:00", "17:00"};
    for (String slot : timeSlots) {
        tableModel.addRow(new Object[]{slot, "", "", "", "", ""});
    }

    String sql = "SELECT a.horario, a.semana, cu.nome "
                 + "FROM agenda a "
                 + "INNER JOIN cad_usuarios cu ON a.usuario_id = cu.id";

    try (PreparedStatement pstAgendamentos = conexao.prepareStatement(sql);
         ResultSet rsAgendamentos = pstAgendamentos.executeQuery()) {
        while (rsAgendamentos.next()) {
            String horarioBanco = rsAgendamentos.getString("horario");
            String diaSemana = rsAgendamentos.getString("semana");
            String nomeUsuario = rsAgendamentos.getString("nome");

            int rowIndex = getRowIndexByTimeSlot(horarioBanco);
            int colIndex = getColumnIndexByDay(diaSemana);

            if (rowIndex != -1 && colIndex != -1) {
                tableModel.setValueAt(nomeUsuario, rowIndex, colIndex);
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar agendamentos: " + e.getMessage());
    }
    ajustarTamanhoColunas(); // Ajusta o tamanho das colunas APÓS carregar os dados
}
    
    private int getRowIndexByTimeSlot(String timeSlotFromDatabase) {
        String timePartFromDatabase = timeSlotFromDatabase.substring(0, 5); // Pega "HH:mm"
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(timePartFromDatabase)) {
                return i;
            }
        }
        return -1;
    }

    private int getColumnIndexByDay(String day) {
        switch (day) {
            case "Segunda-Feira":
                return 1;
            case "Terça-Feira":
                return 2;
            case "Quarta-Feira":
                return 3;
            case "Quinta-Feira":
                return 4;
            case "Sexta-Feira":
                return 5;
            default:
                return -1;
        }
    }
    
    private int buscarIdUsuarioPorNome(String nome) {
        String sql = "SELECT id FROM cad_usuarios WHERE nome = ?";
        try (PreparedStatement pstBuscaId = conexao.prepareStatement(sql);) {
            pstBuscaId.setString(1, nome);
            try (ResultSet rsBuscaId = pstBuscaId.executeQuery()) {
                if (rsBuscaId.next()) {
                    return rsBuscaId.getInt("id");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar ID do usuário: " + e.getMessage());
        }
        return -1; // Usuário não encontrado
    }
    
    private void addTimeSlots() {
        String[] timeSlots = {"08:00:00", "09:00:00", "10:00:00", "11:00:00", "12:00:00",
                    "14:00:00", "15:00:00", "16:00:00", "17:00:00"};
        for (String slot : timeSlots) {
            tableModel.addRow(new Object[]{slot, "", "", "", "", ""});
        }
    }
    
     private void addEventToTable() {
        String timeSlot = JOptionPane.showInputDialog(this, "Insira o horário (ex: 09:00):");
        if (timeSlot != null && !timeSlot.isEmpty()) {
            String day = (String) JOptionPane.showInputDialog(this, 
                "Escolha o dia da semana:", 
                "Dia da semana", 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                new String[]{"Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira"}, 
                "Segunda-Feira");
            
            String event = JOptionPane.showInputDialog(this, "Insira o evento:");
            if (event != null && !event.isEmpty() && day != null) {
                int rowIndex = getRowIndexByTimeSlot(timeSlot);
                if (rowIndex != -1) {
                    int colIndex = getColumnIndexByDay(day);
                    if (colIndex != -1) {
                        tableModel.setValueAt(event, rowIndex, colIndex);
                    }
                }
            }
        }
    }

   

  
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnColocarAg = new javax.swing.JButton();
        txtNomeAg = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnLiberarAg = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Agenda");
        setToolTipText("");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setPreferredSize(new java.awt.Dimension(580, 420));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Calendario");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btnColocarAg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/Add_User-80_icon-icons.com_57380.png"))); // NOI18N
        btnColocarAg.setText("Inserir");
        btnColocarAg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnColocarAgActionPerformed(evt);
            }
        });

        txtNomeAg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeAgActionPerformed(evt);
            }
        });

        jLabel2.setText("Nome:");

        btnLiberarAg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/Remove_User-80_icon-icons.com_57283.png"))); // NOI18N
        btnLiberarAg.setText("Retirar");
        btnLiberarAg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLiberarAgActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/logo 128x128.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(162, 162, 162)
                                .addComponent(btnColocarAg)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLiberarAg)
                                .addGap(167, 167, 167))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNomeAg))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(252, 252, 252)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(96, 96, 96)
                                .addComponent(jLabel3)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jScrollPane1)
                        .addGap(64, 64, 64)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNomeAg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2)))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnColocarAg)
                            .addComponent(btnLiberarAg))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        setBounds(0, 0, 775, 527);
    }// </editor-fold>//GEN-END:initComponents

    private void btnColocarAgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnColocarAgActionPerformed
    String nomeUsuarioAgendado = txtNomeAg.getText(); // Mantemos o nome para o agendamento

    if (nomeUsuarioAgendado.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, insira um nome para agendamento.");
        return;
    }

    String timeSlot = (String) JOptionPane.showInputDialog(this,
            "Escolha o horário:",
            "Horário",
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"08:00", "09:00", "10:00", "11:00", "12:00",
                    "14:00", "15:00", "16:00", "17:00"},
            "08:00");

    if (timeSlot != null) {
        String timeSlotWithSeconds = timeSlot + ":00";
        String day = (String) JOptionPane.showInputDialog(this,
                "Escolha o dia da semana:",
                "Dia da semana",
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira"},
                "Segunda-Feira");
        if (day != null) {
            // 1. Obter o ID do funcionário logado
            int funcionarioLogadoId = buscarIdUsuarioPorLogin(this.usuarioLogado);

            // 2. Buscar o ID do usuário agendado (da tabela cad_usuarios)
            int usuarioAgendadoId = buscarIdUsuarioPorNome(nomeUsuarioAgendado);

            if (funcionarioLogadoId != -1) {
                if (usuarioAgendadoId != -1) {
                    String sqlInsertAgenda = "INSERT INTO agenda (horario, semana, usuario_id, usuario_inseriu_id) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement pstInsertAgenda = conexao.prepareStatement(sqlInsertAgenda, Statement.RETURN_GENERATED_KEYS)) {
                        pstInsertAgenda.setString(1, timeSlotWithSeconds);
                        pstInsertAgenda.setString(2, day);
                        pstInsertAgenda.setInt(3, usuarioAgendadoId);
                        pstInsertAgenda.setInt(4, funcionarioLogadoId);
                        pstInsertAgenda.executeUpdate();

                        // Recupera o ID do agendamento inserido
                        ResultSet generatedKeys = pstInsertAgenda.getGeneratedKeys();
                        int idAgendamentoInserido = -1;
                        if (generatedKeys.next()) {
                            idAgendamentoInserido = generatedKeys.getInt(1);
                        }

                        if (idAgendamentoInserido != -1) {
                            String sqlInsertHistorico = "INSERT INTO agenda_historico_add_rm (acao, id_agenda, usuario_acao_id, semana, horario, usuario_agendado_id) VALUES (?, ?, ?, ?, ?, ?)";
                            try (PreparedStatement pstInsertHistorico = conexao.prepareStatement(sqlInsertHistorico)) {
                                pstInsertHistorico.setString(1, "ADICIONADO");
                                pstInsertHistorico.setInt(2, idAgendamentoInserido);
                                pstInsertHistorico.setInt(3, funcionarioLogadoId);
                                pstInsertHistorico.setString(4, day);
                                pstInsertHistorico.setString(5, timeSlotWithSeconds);
                                pstInsertHistorico.setInt(6, usuarioAgendadoId);
                                pstInsertHistorico.executeUpdate();
                                carregarAgendamentos();
                                JOptionPane.showMessageDialog(this, "Agendamento realizado com sucesso!");
                            } catch (SQLException e) {
                                JOptionPane.showMessageDialog(this, "Erro ao registrar histórico de adição: " + e.getMessage());
                            }
                        } else {
                            JOptionPane.showMessageDialog(this, "Erro ao obter ID do agendamento.");
                        }

                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(this, "Erro ao agendar: " + e.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Usuário a ser agendado não encontrado.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao obter ID do funcionário logado.");
            }
        }
    }

    }//GEN-LAST:event_btnColocarAgActionPerformed

    
    
    private void btnLiberarAgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLiberarAgActionPerformed
String timeSlot = (String) JOptionPane.showInputDialog(this,
            "Escolha o horário:",
            "Horário",
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"08:00", "09:00", "10:00", "11:00", "12:00",
                    "14:00", "15:00", "16:00", "17:00"},
            "08:00");

    if (timeSlot != null) {
        String day = (String) JOptionPane.showInputDialog(this,
                "Escolha o dia da semana:",
                "Dia da semana",
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira"},
                "Segunda-Feira");

        if (day != null) {
            String sqlSelectAgendamento = "SELECT id, usuario_id FROM agenda WHERE horario = ? AND semana = ?";
            String sqlInsertHistorico = "INSERT INTO agenda_historico_add_rm (acao, id_agenda, usuario_acao_id, semana, horario, usuario_agendado_id) VALUES (?, ?, ?, ?, ?, ?)";
            String sqlDelete = "DELETE FROM agenda WHERE horario = ? AND semana = ?";

            try (PreparedStatement pstSelect = conexao.prepareStatement(sqlSelectAgendamento);
                 PreparedStatement pstInsertHistorico = conexao.prepareStatement(sqlInsertHistorico);
                 PreparedStatement pstDelete = conexao.prepareStatement(sqlDelete)) {

                pstSelect.setString(1, timeSlot + ":00");
                pstSelect.setString(2, day);
                ResultSet rsAgendamento = pstSelect.executeQuery();
                int idAgendamentoRemovido = -1;
                int usuarioAgendadoIdRemovido = -1;
                if (rsAgendamento.next()) {
                    idAgendamentoRemovido = rsAgendamento.getInt("id");
                    usuarioAgendadoIdRemovido = rsAgendamento.getInt("usuario_id");
                }

                int funcionarioLogadoId = buscarIdUsuarioPorLogin(this.usuarioLogado);

                if (funcionarioLogadoId != -1 && idAgendamentoRemovido != -1) {
                    pstInsertHistorico.setString(1, "REMOVIDO");
                    pstInsertHistorico.setInt(2, idAgendamentoRemovido);
                    pstInsertHistorico.setInt(3, funcionarioLogadoId);
                    pstInsertHistorico.setString(4, day);
                    pstInsertHistorico.setString(5, timeSlot + ":00");
                    pstInsertHistorico.setInt(6, usuarioAgendadoIdRemovido);
                    pstInsertHistorico.executeUpdate();

                    pstDelete.setString(1, timeSlot + ":00");
                    pstDelete.setString(2, day);
                    int rowsDeleted = pstDelete.executeUpdate();

                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(this, "Agendamento removido com sucesso!");
                        carregarAgendamentos();
                    } else {
                        JOptionPane.showMessageDialog(this, "Nenhum agendamento encontrado para o horário e dia selecionados.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao obter ID do usuário logado ou do agendamento.");
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Erro ao remover agendamento: " + e.getMessage());
            }
        }
    }
    }//GEN-LAST:event_btnLiberarAgActionPerformed

    // Você precisará criar este método para buscar o ID do usuário logado na tabela login_funcionario pelo login
private int buscarIdUsuarioPorLogin(String login) {
    String sql = "SELECT id FROM login_funcionario WHERE login = ?";
    try (PreparedStatement pstBuscaId = conexao.prepareStatement(sql)) {
        pstBuscaId.setString(1, login);
        try (ResultSet rsBuscaId = pstBuscaId.executeQuery()) {
            if (rsBuscaId.next()) {
                return rsBuscaId.getInt("id");
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao buscar ID do usuário por login: " + e.getMessage());
    }
    return -1; // Usuário não encontrado
}

    
    private void txtNomeAgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeAgActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeAgActionPerformed

private void implementarAutocompletar() {
        JPopupMenu popupMenu = new JPopupMenu();
        JList<String> sugestoesList = new JList<>();
        DefaultListModel<String> listModel = new DefaultListModel<>();
        sugestoesList.setModel(listModel);
        popupMenu.add(sugestoesList);

        txtNomeAg.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String textoDigitado = txtNomeAg.getText().trim();
                listModel.clear();
                if (!textoDigitado.isEmpty()) {
                    for (String nome : listaNomesUsuarios) {
                        if (nome.toLowerCase().startsWith(textoDigitado.toLowerCase())) {
                            listModel.addElement(nome);
                        }
                    }
                    if (listModel.getSize() > 0) {
                        int x = txtNomeAg.getLocationOnScreen().x;
                        int y = txtNomeAg.getLocationOnScreen().y + txtNomeAg.getHeight();
                        popupMenu.show(null, x, y); // Mostra o popup na tela
                    } else {
                        popupMenu.setVisible(false);
                    }
                } else {
                    popupMenu.setVisible(false);
                }
            }
        });

        sugestoesList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedName = sugestoesList.getSelectedValue();
                if (selectedName != null) {
                    txtNomeAg.setText(selectedName);
                    popupMenu.setVisible(false);
                }
            }
        });

        // Esconde o popup quando o foco do campo de texto é perdido
        txtNomeAg.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                popupMenu.setVisible(false);
            }
        });
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnColocarAg;
    private javax.swing.JButton btnLiberarAg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtNomeAg;
    // End of variables declaration//GEN-END:variables
}
