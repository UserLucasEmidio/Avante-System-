/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.avante.telas;

import br.com.avante.dal.ModuloConexao;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import br.com.avante.Estilizacao.Estilizacao; // Importe a classe Estilizacao
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author lucas
 */
public class Funcionario_Historico extends javax.swing.JFrame {
    Connection conexao = null;
    DefaultTableModel modeloTabelaHistorico = new DefaultTableModel(null, new String[]{"Funcionario", "Ação", "Usuario", "Dia", "Horário"});
    DefaultTableModel modeloTabelaLogAcessos = new DefaultTableModel(null, new String[]{"Funcionario", "Horário de Acesso", "Data de Acesso"});
    private String ordenacao = "Todos"; // Variável para rastrear a ordenação do log de acessos
    
    
    /**
     * Creates new form Funcionario_Historico
     */
    public Funcionario_Historico() {
        initComponents();
        conexao = ModuloConexao.conector();
        modeloTabelaHistorico = new DefaultTableModel(null, new String[]{"Funcionario", "Ação", "Usuario", "Dia", "Horário"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tornar todas as células não editáveis
            }
        };
        txtagenda_historico_add_rm.setModel(modeloTabelaHistorico); // Defina o modelo *depois* da modificação
        txtagenda_historico_add_rm.setCellSelectionEnabled(false); // Desabilita a seleção de células

        modeloTabelaLogAcessos = new DefaultTableModel(null, new String[]{"Funcionario", "Horário de Acesso", "Data de Acesso"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tornar todas as células não editáveis
            }
        };
        
        txtlog_acessos.setModel(modeloTabelaLogAcessos);
        txtlog_acessos.setCellSelectionEnabled(false); // Desabilita a seleção de células
        
        txtlog_acessos.setModel(modeloTabelaLogAcessos); // Defina o modelo *depois* da modificação
        carregarFiltroAgendamentos(); // Inicializa o JComboBox de filtro
        carregarHistoricoAgendamentos("Todos", ""); // Carrega todos os dados inicialmente (sem filtro de funcionário)
        carregarFiltroLogins(); // Inicializa o JComboBox de filtro de logins
        adicionarListeners(); // Chama o método para adicionar os listeners
        carregarLogAcessos(); // Carrega os logs de acesso inicialmente
        // Define o comportamento de fechamento da janela
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        // Ou, se preferir esconder a janela ao invés de liberar os recursos:
        // setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);

        // Define o layout para GridBagLayout
        setLayout(new GridBagLayout());
        adicionarComponentesGridBag();

        // Define o tamanho inicial da janela
        setSize(800, 500);

        // Centraliza a janela na tela
        setLocationRelativeTo(null);
        aplicarEstilos(); // Chame aplicarEstilos aqui
    }
    
    
        private void aplicarEstilos() {
        Estilizacao.estilizarLabelTitulo(jLabel3); // Historico de Agendamento
        Estilizacao.estilizarLabelTitulo(jLabel4); // Historico Login
        Estilizacao.estilizarLabelPadrao(jLabel1); // Filtro
        Estilizacao.estilizarLabelPadrao(jLabel2); // Login
        Estilizacao.estilizarLabelPadrao(jLabel5); // Funcionario (filtro agendamento)
        Estilizacao.estilizarLabelPadrao(jLabel6); // Funcionario (filtro login)

        Estilizacao.estilizarTextFieldPadrao(txtFuncionarioFiltro);
        Estilizacao.estilizarTextFieldPadrao(txtLoginFiltro);

        Estilizacao.estilizarComboBoxPadrao(txtFiltroAgendamento);
        Estilizacao.estilizarComboBoxPadrao(txtFiltroLoginAcesso);

        Estilizacao.estilizarTabelaPadrao(txtagenda_historico_add_rm);
        Estilizacao.estilizarScrollPane(jScrollPane2);
        Estilizacao.estilizarTabelaPadrao(txtlog_acessos);
        Estilizacao.estilizarScrollPane(jScrollPane1);

        this.getContentPane().setBackground(Estilizacao.COR_DE_FUNDO);
    }
    
    
    
private void adicionarComponentesGridBag() {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5); // Margens padrão

    // Linha 0: Título "Historico de Agendamento"
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = GridBagConstraints.REMAINDER; // Ocupa o restante da linha
    gbc.weightx = 1.0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.CENTER;
    add(jLabel3, gbc);

    // Linha 1: Filtros do Histórico de Agendamento
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 1;
    gbc.weightx = 0.0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.anchor = GridBagConstraints.WEST;
    add(jLabel1, gbc);

    gbc.gridx = 1;
    gbc.gridy = 1;
    gbc.weightx = 0.3;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    add(txtFiltroAgendamento, gbc);

    gbc.gridx = 2;
    gbc.gridy = 1;
    gbc.weightx = 0.0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.anchor = GridBagConstraints.EAST;
    add(jLabel5, gbc);

    gbc.gridx = 3;
    gbc.gridy = 1;
    gbc.weightx = 0.7;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridwidth = GridBagConstraints.REMAINDER; // Ocupa o restante da linha
    add(txtFuncionarioFiltro, gbc);

    // Linha 2: Painel para a Tabela de Histórico de Agendamento
    JPanel panelHistoricoAgendamento = new JPanel(new BorderLayout());
    panelHistoricoAgendamento.add(jScrollPane2, BorderLayout.CENTER);

    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridwidth = GridBagConstraints.REMAINDER; // Ocupa o restante da linha
    gbc.weightx = 1.0;
    gbc.weighty = 0.5;
    gbc.fill = GridBagConstraints.BOTH;
    add(panelHistoricoAgendamento, gbc);

    // Linha 3: Título "Historico Login"
    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridwidth = GridBagConstraints.REMAINDER; // Ocupa o restante da linha
    gbc.weighty = 0.0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.CENTER;
    add(jLabel4, gbc);

    // Linha 4: Filtros do Histórico de Login (mantém como estava)
    gbc.gridx = 0;
    gbc.gridy = 4;
    gbc.gridwidth = 1;
    gbc.weightx = 0.0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.anchor = GridBagConstraints.WEST;
    add(jLabel2, gbc);

    gbc.gridx = 1;
    gbc.gridy = 4;
    gbc.weightx = 0.3;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    add(txtFiltroLoginAcesso, gbc);

    gbc.gridx = 2;
    gbc.gridy = 4;
    gbc.weightx = 0.0;
    gbc.fill = GridBagConstraints.NONE;
    gbc.anchor = GridBagConstraints.EAST;
    add(jLabel6, gbc);

    gbc.gridx = 3;
    gbc.gridy = 4;
    gbc.weightx = 0.7;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    add(txtLoginFiltro, gbc);

    // Linha 5: Painel para a Tabela de Histórico de Login (MODIFICADO NOVAMENTE)
    JPanel panelHistoricoLoginWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0)); // FlowLayout alinhado à esquerda, sem margens
    panelHistoricoLoginWrapper.add(jScrollPane1);

    gbc.gridx = 0;
    gbc.gridy = 5;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.weightx = 1.0; // Deixe o weightx como 1.0 para ocupar o espaço disponível
    gbc.weighty = 0.5;
    gbc.fill = GridBagConstraints.BOTH; // Volte para BOTH
    gbc.anchor = GridBagConstraints.WEST; // ANCORE À ESQUERDA
    add(panelHistoricoLoginWrapper, gbc);

    pack(); // Garante que a janela se redimensione corretamente
}
    
    private void carregarFiltroAgendamentos() {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(new String[]{"Todos", "ADICIONADO", "REMOVIDO"});
        txtFiltroAgendamento.setModel(model);
    }
    
    private void adicionarListeners() {
        txtFuncionarioFiltro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                String filtroAcao = (String) txtFiltroAgendamento.getSelectedItem();
                String filtroFuncionario = txtFuncionarioFiltro.getText();
                carregarHistoricoAgendamentos(filtroAcao, filtroFuncionario);
            }
    });
        txtLoginFiltro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                String filtroLogin = txtLoginFiltro.getText();
                carregarLogAcessos(filtroLogin);
            }
        });
                txtFiltroLoginAcesso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                String filtroSelecionado = (String) txtFiltroLoginAcesso.getSelectedItem();
                ordenacao = filtroSelecionado; // Atualiza a variável de ordenação
                carregarLogAcessos(txtLoginFiltro.getText()); // Recarrega os logs, a ordenação será aplicada dentro do método
            }
        });
        
}
    
    private void carregarLogAcessos(String filtroLogin) {
modeloTabelaLogAcessos.setRowCount(0); // Limpa a tabela

        String sql = "SELECT login, horario_acesso, data_acesso FROM log_acessos";
        String whereClause = "";

        if (!filtroLogin.isEmpty()) {
            whereClause += "login LIKE ?";
        }

        if (!whereClause.isEmpty()) {
            sql += " WHERE " + whereClause;
        }

        if (ordenacao.equals("Data Crescente")) {
            sql += " ORDER BY data_acesso ASC, horario_acesso ASC"; // Ordena por data e hora crescente
        } else if (ordenacao.equals("Data Decrescente")) {
            sql += " ORDER BY data_acesso DESC, horario_acesso DESC"; // Ordena por data e hora decrescente
        } else if (ordenacao.equals("Por Ano")) {
            String anoStr = JOptionPane.showInputDialog(Funcionario_Historico.this, "Digite o ano para filtrar:", "Filtrar por Ano", JOptionPane.QUESTION_MESSAGE);
            if (anoStr != null && !anoStr.isEmpty()) {
                try {
                    int ano = Integer.parseInt(anoStr);
                    sql += " WHERE YEAR(data_acesso) = " + ano + " ORDER BY data_acesso, horario_acesso";
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(Funcionario_Historico.this, "Ano inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
                    // Não precisa recarregar aqui, a tabela manterá o estado atual ou o usuário pode selecionar outra opção
                }
            }
            // Se o ano for cancelado ou inválido, a consulta será sem filtro de ano específico
        }

        try (PreparedStatement pst = conexao.prepareStatement(sql);) {

            int parameterIndex = 1;
            if (!filtroLogin.isEmpty()) {
                pst.setString(parameterIndex++, "%" + filtroLogin + "%");
            }

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                modeloTabelaLogAcessos.addRow(new Object[]{
                        rs.getString("login"),
                        rs.getString("horario_acesso"),
                        rs.getDate("data_acesso")
                });
            }
            txtlog_acessos.setModel(modeloTabelaLogAcessos);
            ajustarTamanhoColunas(txtlog_acessos); // Chama o método para ajustar as colunas

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar log de acessos: " + e.getMessage());
        }
}
    

        private void carregarLogAcessos() {
            carregarLogAcessos("");
}
        private void carregarFiltroLogins() {
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(new String[]{"Todos", "Data Crescente", "Data Decrescente", "Por Ano"});
            txtFiltroLoginAcesso.setModel(model);
}
    private void ajustarTamanhoColunas(JTable tabela) {
    TableColumnModel columnModel = tabela.getColumnModel();
    for (int column = 0; column < tabela.getColumnCount(); column++) {
        int headerWidth = 0;
        int dataWidth = 0;
        TableColumn tableColumn = columnModel.getColumn(column);

        // Obter a largura ideal para o cabeçalho
        TableCellRenderer headerRenderer = tableColumn.getHeaderRenderer();
        if (headerRenderer == null) {
            headerRenderer = tabela.getTableHeader().getDefaultRenderer();
        }
        Component headerComp = headerRenderer.getTableCellRendererComponent(
                tabela, tableColumn.getHeaderValue(), false, false, 0, column);
        FontMetrics headerFM = headerComp.getFontMetrics(headerComp.getFont());
        headerWidth = headerFM.stringWidth(tableColumn.getHeaderValue().toString()) + 20; // Adiciona padding

        // Obter a largura ideal para cada célula da coluna
        for (int row = 0; row < tabela.getRowCount(); row++) {
            TableCellRenderer cellRenderer = tabela.getCellRenderer(row, column);
            Component cellComp = cellRenderer.getTableCellRendererComponent(
                    tabela, tabela.getValueAt(row, column), false, false, row, column);
            FontMetrics cellFM = cellComp.getFontMetrics(cellComp.getFont());
            if (tabela.getValueAt(row, column) != null) {
                dataWidth = Math.max(dataWidth, cellFM.stringWidth(tabela.getValueAt(row, column).toString()) + 20); // Adiciona padding
            }
        }

        // Definir a largura preferida como o máximo entre a largura do cabeçalho e a largura dos dados
        tableColumn.setPreferredWidth(Math.max(headerWidth, dataWidth));
    }
}
        private void carregarHistoricoAgendamentos(String filtroAcao, String filtroFuncionario) {
            
        modeloTabelaHistorico.setRowCount(0); // Limpa a tabela

        String sql = "SELECT "
                + " lf.login AS funcionario_nome, "
                + " ahr.acao, "
                + " cu.nome AS usuario_agendado_nome, "
                + " ahr.semana, "
                + " ahr.horario "
                + "FROM agenda_historico_add_rm ahr "
                + "INNER JOIN login_funcionario lf ON ahr.usuario_acao_id = lf.id "
                + "INNER JOIN cad_usuarios cu ON ahr.usuario_agendado_id = cu.id";

        String whereClause = "";

        if (!filtroAcao.equals("Todos")) {
            whereClause += "ahr.acao = ?";
        }

        if (!filtroFuncionario.isEmpty()) {
            if (!whereClause.isEmpty()) {
                whereClause += " AND ";
            }
            whereClause += "lf.login LIKE ?";
        }

        if (!whereClause.isEmpty()) {
            sql += " WHERE " + whereClause;
        }

        try (PreparedStatement pst = conexao.prepareStatement(sql);) {
        int parameterIndex = 1;
        if (!filtroAcao.equals("Todos")) {
            pst.setString(parameterIndex++, filtroAcao.toUpperCase());
        }
        if (!filtroFuncionario.isEmpty()) {
            pst.setString(parameterIndex++, "%" + filtroFuncionario + "%"); // Use LIKE para auto-complete
        }

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            modeloTabelaHistorico.addRow(new Object[]{
                    rs.getString("funcionario_nome"),
                    rs.getString("acao"),
                    rs.getString("usuario_agendado_nome"),
                    rs.getString("semana"),
                    rs.getString("horario")
            });
        }
        txtagenda_historico_add_rm.setModel(modeloTabelaHistorico);
        ajustarTamanhoColunas(txtagenda_historico_add_rm); // Chama o método para ajustar as colunas
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar histórico de agendamentos: " + e.getMessage());
    }
        

    }
    
 
    
        

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtlog_acessos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtFiltroAgendamento = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        txtFiltroLoginAcesso = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtagenda_historico_add_rm = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtFuncionarioFiltro = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtLoginFiltro = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Histórico de Ação do Funcionario");

        txtlog_acessos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Funcionario", "Horário de Acesso", "Data de Acesso"
            }
        ));
        txtlog_acessos.setCellSelectionEnabled(true);
        jScrollPane1.setViewportView(txtlog_acessos);

        jLabel1.setText("Filtro");

        txtFiltroAgendamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        txtFiltroAgendamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFiltroAgendamentoActionPerformed(evt);
            }
        });

        jLabel2.setText("Login");

        txtFiltroLoginAcesso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        txtFiltroLoginAcesso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFiltroLoginAcessoActionPerformed(evt);
            }
        });

        txtagenda_historico_add_rm.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Funcionario", "Ação", "Usuario", "Dia", "Horário"
            }
        ));
        txtagenda_historico_add_rm.setCellSelectionEnabled(true);
        txtagenda_historico_add_rm.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane2.setViewportView(txtagenda_historico_add_rm);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Historico de Agendamento");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Historico Login");

        jLabel5.setText("Funcionario:");

        jLabel6.setText("Funcionario:");

        txtLoginFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLoginFiltroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(157, 157, 157))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFiltroAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFiltroLoginAcesso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtLoginFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFuncionarioFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(198, 198, 198)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtFiltroAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFuncionarioFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtFiltroLoginAcesso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtLoginFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFiltroLoginAcessoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFiltroLoginAcessoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFiltroLoginAcessoActionPerformed

    private void txtFiltroAgendamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFiltroAgendamentoActionPerformed
        // TODO add your handling code here:
        String filtroSelecionado = (String) txtFiltroAgendamento.getSelectedItem();
        String filtroFuncionario = txtFuncionarioFiltro.getText(); // Obtém o filtro de funcionário atual
        carregarHistoricoAgendamentos(filtroSelecionado, filtroFuncionario); // Passa ambos os filtros
    }//GEN-LAST:event_txtFiltroAgendamentoActionPerformed

    private void txtLoginFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLoginFiltroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLoginFiltroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Funcionario_Historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Funcionario_Historico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> txtFiltroAgendamento;
    private javax.swing.JComboBox<String> txtFiltroLoginAcesso;
    private javax.swing.JTextField txtFuncionarioFiltro;
    private javax.swing.JTextField txtLoginFiltro;
    private javax.swing.JTable txtagenda_historico_add_rm;
    private javax.swing.JTable txtlog_acessos;
    // End of variables declaration//GEN-END:variables

    void setSelected(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
