/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package br.com.avante.telas;

import br.com.avante.dal.ModuloConexao;
import br.com.avante.Estilizacao.Estilizacao;
import java.awt.Color;
import java.awt.Font;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.util.Date;
import java.util.Calendar;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;
/**
 *
 * @author lucas
 */
public class TelaCadastro extends javax.swing.JInternalFrame {

    /**
     * Creates new form TelaCadastro
     * 
     * 
     */
    
    private void aplicarEstilos() {
        Estilizacao.estilizarLabelTitulo(jLabel1); // Título da tela
        Estilizacao.estilizarLabelPadrao(jLabel2); // Nome*
        Estilizacao.estilizarLabelPadrao(jLabel3); // CPF*
        Estilizacao.estilizarLabelPadrao(jLabel4); // RG
        Estilizacao.estilizarLabelPadrao(jLabel5); // Endereço*
        Estilizacao.estilizarLabelPadrao(jLabel6); // Nascimento:
        Estilizacao.estilizarLabelPadrao(jLabel12); // 1º Contato:*
        Estilizacao.estilizarLabelPadrao(jLabel13); // 2º Contato
        Estilizacao.estilizarLabelPadrao(jLabel14); // Tipo (1º Contato)
        Estilizacao.estilizarLabelPadrao(jLabel15); // Tipo (2º Contato)
        Estilizacao.estilizarLabelPadrao(jLabel16); // Nº
        Estilizacao.estilizarLabelPadrao(LabelWorkCad); // Trabalha?
        Estilizacao.estilizarLabelPadrao(labelSAdquisaoCad); // Substância de Adquisão:
        Estilizacao.estilizarLabelPadrao(jLabel8); // Profissão:
        Estilizacao.estilizarLabelPadrao(jLabel10); // Qual Substância?
        Estilizacao.estilizarLabelPadrao(jLabel9); // Campo onde tem * é obrigatório

        Estilizacao.estilizarTextFieldPadrao(txtNomeCad);
        Estilizacao.estilizarTextFieldPadrao(txtCPFCad);
        Estilizacao.estilizarTextFieldPadrao(txtRgCad);
        Estilizacao.estilizarTextFieldPadrao(txtEndCad);
        Estilizacao.estilizarTextFieldPadrao(txtNumberCad);
        Estilizacao.estilizarTextFieldPadrao(txtContato1Cad);
        Estilizacao.estilizarTextFieldPadrao(txtContato2Cad);
        Estilizacao.estilizarTextFieldPadrao(txtContatoTipo1Cad);
        Estilizacao.estilizarTextFieldPadrao(txtContatoTipo2Cad);
        Estilizacao.estilizarTextFieldPadrao(txtProfissaoCad);
        Estilizacao.estilizarTextFieldPadrao(txtWSubstanciaCad);

        Estilizacao.estilizarBotaoPadrao(btnCadastrarCad);

        // Se você tiver estilos específicos para CheckBoxes ou JSpinners:
        // Estilizacao.estilizarCheckBoxPadrao(chb1YesCad);
        // Estilizacao.estilizarCheckBoxPadrao(chb1NoCad);
        // Estilizacao.estilizarCheckBoxPadrao(chb2YesCad);
        // Estilizacao.estilizarCheckBoxPadrao(chb2NoCad);
        // Estilizacao.estilizarJSpinnerPadrao(jspNascimento);

        this.getContentPane().setBackground(Estilizacao.COR_DE_FUNDO); // Cor de fundo da tela
    }
    
    public TelaCadastro() {
        
        initComponents();
        aplicarEstilos(); // Chame aplicarEstilos aqui
        
        // Define o formato de data para o JSpinner
        Date date = new Date();
        SpinnerDateModel sm = new SpinnerDateModel(date, null, null, Calendar.DAY_OF_MONTH);
        jspNascimento.setModel(sm);
        JSpinner.DateEditor de = new JSpinner.DateEditor(jspNascimento, "dd/MM/yyyy");
        jspNascimento.setEditor(de);
        
        // Seleciona o chb2YesCad por padrão
        chb2YesCad.setSelected(true);  // <---  Código inserido aqui!

        // Define o limite de caracteres e a formatação para o campo CPF
        ((AbstractDocument) txtCPFCad.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder sb = new StringBuilder(currentText);
                sb.insert(offset, string);
                String newText = sb.toString().replaceAll("[^\\d]", ""); // Remove não-dígitos temporariamente

                if (newText.length() <= 11 && string.matches("\\d*")) {
                    StringBuilder formatted = new StringBuilder();
                    for (int i = 0; i < newText.length(); i++) {
                        formatted.append(newText.charAt(i));
                        if (i == 2 || i == 5) {
                            formatted.append('.');
                        } else if (i == 8) {
                            formatted.append('-');
                        }
                    }
                    super.replace(fb, 0, fb.getDocument().getLength(), formatted.toString(), attr);
                }
            }
    
    

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder sb = new StringBuilder(currentText);
                sb.replace(offset, offset + length, text);
                String newText = sb.toString().replaceAll("[^\\d]", ""); // Remove não-dígitos temporariamente

                if (newText.length() <= 11 && text.matches("\\d*")) {
                    StringBuilder formatted = new StringBuilder();
                    for (int i = 0; i < newText.length(); i++) {
                        formatted.append(newText.charAt(i));
                        if (i == 2 || i == 5) {
                            formatted.append('.');
                        } else if (i == 8) {
                            formatted.append('-');
                        }
                    }
                    super.replace(fb, 0, fb.getDocument().getLength(), formatted.toString(), attrs);
                }
            }
        });


        // Define o limite de caracteres e a formatação para o campo RG
        ((AbstractDocument) txtRgCad.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder sb = new StringBuilder(currentText);
                sb.insert(offset, string);
                String newText = sb.toString().replaceAll("[^\\d]", ""); // Remove não-dígitos temporariamente

                int maxLength = 9; // Ajuste para o tamanho máximo do seu RG (sem formatação)
                if (newText.length() <= maxLength && string.matches("\\d*")) {
                    StringBuilder formatted = new StringBuilder();
                    int pointCount = 0;
                    for (int i = 0; i < newText.length(); i++) {
                        formatted.append(newText.charAt(i));
                        if ((i == 1 || i == 4) && pointCount < 2) { // Exemplo: após o 2º e 5º dígito
                            formatted.append('.');
                            pointCount++;
                        } else if (i == 7 && maxLength > 8) { // Exemplo: antes do dígito verificador
                            formatted.append('-');
                        }
                    }
                    super.replace(fb, 0, fb.getDocument().getLength(), formatted.toString(), attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder sb = new StringBuilder(currentText);
                sb.replace(offset, offset + length, text);
                String newText = sb.toString().replaceAll("[^\\d]", ""); // Remove não-dígitos temporariamente

                int maxLength = 9; // Ajuste para o tamanho máximo do seu RG (sem formatação)
                if (newText.length() <= maxLength && text.matches("\\d*")) {
                    StringBuilder formatted = new StringBuilder();
                    int pointCount = 0;
                    for (int i = 0; i < newText.length(); i++) {
                        formatted.append(newText.charAt(i));
                        if ((i == 1 || i == 4) && pointCount < 2) { // Exemplo: após o 2º e 5º dígito
                            formatted.append('.');
                            pointCount++;
                        } else if (i == 7 && maxLength > 8) { // Exemplo: antes do dígito verificador
                            formatted.append('-');
                        }
                    }
                    super.replace(fb, 0, fb.getDocument().getLength(), formatted.toString(), attrs);
                }
            }
        });

        // Define o limite de caracteres para o campo Contato 1
        ((AbstractDocument) txtContato1Cad.getDocument()).setDocumentFilter(new DocumentFilter() {
            private int maxCharacters = 15; // Defina o número máximo de caracteres desejado

            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if ((fb.getDocument().getLength() + string.length()) <= maxCharacters && string.matches("\\d*")) {
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if ((fb.getDocument().getLength() - length + text.length()) <= maxCharacters && text.matches("\\d*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        // Define o limite de caracteres para o campo Contato 2
        ((AbstractDocument) txtContato2Cad.getDocument()).setDocumentFilter(new DocumentFilter() {
            private int maxCharacters = 15; // Defina o número máximo de caracteres desejado

            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if ((fb.getDocument().getLength() + string.length()) <= maxCharacters && string.matches("\\d*")) {
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if ((fb.getDocument().getLength() - length + text.length()) <= maxCharacters && text.matches("\\d*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        LabelWorkCad = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        chb1YesCad = new javax.swing.JCheckBox();
        chb1NoCad = new javax.swing.JCheckBox();
        txtNomeCad = new javax.swing.JTextField();
        txtEndCad = new javax.swing.JTextField();
        txtCPFCad = new javax.swing.JTextField();
        txtRgCad = new javax.swing.JTextField();
        txtProfissaoCad = new javax.swing.JTextField();
        labelSAdquisaoCad = new javax.swing.JLabel();
        chb2YesCad = new javax.swing.JCheckBox();
        chb2NoCad = new javax.swing.JCheckBox();
        jLabel10 = new javax.swing.JLabel();
        txtWSubstanciaCad = new javax.swing.JTextField();
        btnCadastrarCad = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtContato1Cad = new javax.swing.JTextField();
        txtContato2Cad = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtContatoTipo1Cad = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtContatoTipo2Cad = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtNumberCad = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jspNascimento = new javax.swing.JSpinner();

        setBackground(new java.awt.Color(100, 250, 100));
        setMaximizable(true);
        setTitle("Cadastro");
        setToolTipText("");

        jLabel2.setText("*Nome:");

        jLabel3.setText("*CPF:");

        jLabel4.setText("RG:");

        jLabel5.setText("*Endereço:");

        LabelWorkCad.setText("Trabalha?");

        jLabel8.setText("Profissão:");

        buttonGroup1.add(chb1YesCad);
        chb1YesCad.setText("Sim");
        chb1YesCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb1YesCadActionPerformed(evt);
            }
        });

        buttonGroup1.add(chb1NoCad);
        chb1NoCad.setText("Não");

        txtRgCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRgCadActionPerformed(evt);
            }
        });

        txtProfissaoCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProfissaoCadActionPerformed(evt);
            }
        });

        labelSAdquisaoCad.setText("Substância de Adquisão:");

        buttonGroup2.add(chb2YesCad);
        chb2YesCad.setText("Sim");

        buttonGroup2.add(chb2NoCad);
        chb2NoCad.setText("Não");
        chb2NoCad.setEnabled(false);
        chb2NoCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb2NoCadActionPerformed(evt);
            }
        });

        jLabel10.setText("Qual Substância?");

        txtWSubstanciaCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWSubstanciaCadActionPerformed(evt);
            }
        });

        btnCadastrarCad.setText("Cadastrar");
        btnCadastrarCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarCadActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Cadastrar Usuário");

        jLabel12.setText("*1 º Contato:");

        jLabel13.setText("2 º Contato:");

        jLabel14.setText("Tipo:");

        txtContatoTipo1Cad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContatoTipo1CadActionPerformed(evt);
            }
        });

        jLabel15.setText("Tipo:");

        jLabel16.setText("Nº:");

        jLabel9.setText("Campo aonde tem * é obrigatório");

        jLabel6.setText("*Nascimento:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(225, 225, 225)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(jLabel9)))
                .addGap(60, 60, 60))
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelWorkCad)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(50, 50, 50))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(34, 34, 34)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtEndCad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(txtCPFCad, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(22, 22, 22)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtRgCad, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtNomeCad, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(18, 18, 18))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addGap(22, 22, 22))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addGap(27, 27, 27)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jspNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtContato1Cad, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtContato2Cad, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(btnCadastrarCad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(chb1YesCad)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(chb1NoCad))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(chb2YesCad)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(chb2NoCad))
                                        .addComponent(labelSAdquisaoCad, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addGap(67, 67, 67)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel10)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addGap(39, 39, 39)
                                            .addComponent(jLabel8)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtWSubstanciaCad)
                                        .addComponent(txtProfissaoCad)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(260, 260, 260)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtContatoTipo2Cad)
                                        .addComponent(txtNumberCad)
                                        .addComponent(txtContatoTipo1Cad, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(94, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(1, 1, 1)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNomeCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtCPFCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtEndCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(txtRgCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jspNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtContato1Cad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(txtContato2Cad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(txtNumberCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(txtContatoTipo1Cad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(txtContatoTipo2Cad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LabelWorkCad)
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chb1YesCad)
                            .addComponent(chb1NoCad))
                        .addGap(15, 15, 15)
                        .addComponent(labelSAdquisaoCad)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chb2YesCad)
                            .addComponent(chb2NoCad)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtWSubstanciaCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtProfissaoCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(10, 10, 10)
                .addComponent(btnCadastrarCad, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
        );

        setBounds(0, 0, 611, 474);
    }// </editor-fold>//GEN-END:initComponents

    private void chb1YesCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb1YesCadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chb1YesCadActionPerformed

    private void chb2NoCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb2NoCadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chb2NoCadActionPerformed

    private void btnCadastrarCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarCadActionPerformed
         // Coleta os dados do formulário
        String nome = txtNomeCad.getText();
        // Remove a formatação do CPF antes de salvar
        String cpf = txtCPFCad.getText().replaceAll("[.-]", "");
        // Remove a formatação do RG antes de salvar (se houver)
        String rg = txtRgCad.getText().replaceAll("[.-]", "");
        String endereco = txtEndCad.getText();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String nascimento = sdf.format(((Date) jspNascimento.getValue()));
        String numero = txtNumberCad.getText();
        String contato1 = txtContato1Cad.getText();
        String contatoTipo1 = txtContatoTipo1Cad.getText();
        String contato2 = txtContato2Cad.getText();
        String contatoTipo2 = txtContatoTipo2Cad.getText();
        String profissao = txtProfissaoCad.getText();
        String substancia = txtWSubstanciaCad.getText();

        // Verifica se trabalha
        String trabalha = chb1YesCad.isSelected() ? "Sim" : "Não";

        // Verifica se possui substância de aquisição
        String substanciaAquisicao = chb2YesCad.isSelected() ? "Sim" : "Não";

        // Validação dos campos obrigatórios
        if (nome.isEmpty() || cpf.isEmpty() || endereco.isEmpty() || contato1.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Os campos Nome, CPF, Endereço e 1º Contato são obrigatórios.");
            return; // Impede o cadastro se os campos obrigatórios não estiverem preenchidos
        }

        // Conexão com o banco de dados usando o ModuloConexao
        Connection conn = ModuloConexao.conector();
        if (conn != null) {
            try {
                String sql = "INSERT INTO cad_usuarios (nome, cpf, rg, endereco, nascimento, numero, primeiro_contato, primeiro_contato_tipo, segundo_contato, segundo_contato_tipo, trabalha, profissao, substancia_aquisicao, qual_substancia) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, nome);
                    pstmt.setString(2, cpf);
                    pstmt.setString(3, rg);
                    pstmt.setString(4, endereco);
                    pstmt.setString(5, nascimento);
                    pstmt.setString(6, numero);
                    pstmt.setString(7, contato1);
                    pstmt.setString(8, contatoTipo1);
                    pstmt.setString(9, contato2);
                    pstmt.setString(10, contatoTipo2);
                    pstmt.setString(11, trabalha);
                    pstmt.setString(12, profissao);
                    pstmt.setString(13, substanciaAquisicao);
                    pstmt.setString(14, substancia);
                    // Executa a inserção
                    pstmt.executeUpdate();
                    // Fecha a conexão
                }
                conn.close();

                // Exibe uma mensagem de sucesso
                JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!");

                // Limpa os campos do formulário
                txtNomeCad.setText("");
                txtCPFCad.setText("");
                txtRgCad.setText("");
                txtEndCad.setText("");
                // Define a data atual para o JSpinner após limpar
                jspNascimento.setValue(new Date());
                txtNumberCad.setText("");
                txtContato1Cad.setText("");
                txtContatoTipo1Cad.setText("");
                txtContato2Cad.setText("");
                txtContatoTipo2Cad.setText("");
                txtProfissaoCad.setText("");
                txtWSubstanciaCad.setText("");
                buttonGroup1.clearSelection();
                buttonGroup2.clearSelection();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar usuário: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao conectar ao banco de dados.");
        }

    

    }//GEN-LAST:event_btnCadastrarCadActionPerformed

    private void txtRgCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRgCadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRgCadActionPerformed

    private void txtContatoTipo1CadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContatoTipo1CadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContatoTipo1CadActionPerformed

    private void txtProfissaoCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProfissaoCadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProfissaoCadActionPerformed

    private void txtWSubstanciaCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWSubstanciaCadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWSubstanciaCadActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelWorkCad;
    private javax.swing.JButton btnCadastrarCad;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox chb1NoCad;
    private javax.swing.JCheckBox chb1YesCad;
    private javax.swing.JCheckBox chb2NoCad;
    private javax.swing.JCheckBox chb2YesCad;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSpinner jspNascimento;
    private javax.swing.JLabel labelSAdquisaoCad;
    private javax.swing.JTextField txtCPFCad;
    private javax.swing.JTextField txtContato1Cad;
    private javax.swing.JTextField txtContato2Cad;
    private javax.swing.JTextField txtContatoTipo1Cad;
    private javax.swing.JTextField txtContatoTipo2Cad;
    private javax.swing.JTextField txtEndCad;
    private javax.swing.JTextField txtNomeCad;
    private javax.swing.JTextField txtNumberCad;
    private javax.swing.JTextField txtProfissaoCad;
    private javax.swing.JTextField txtRgCad;
    private javax.swing.JTextField txtWSubstanciaCad;
    // End of variables declaration//GEN-END:variables
}
