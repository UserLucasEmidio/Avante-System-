/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.avante.telas;

import br.com.avante.Estilizacao.Estilizacao;
import java.sql.*;
import br.com.avante.dal.ModuloConexao;
import javax.swing.JOptionPane;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author lucas
 */
public class TelaLogin extends javax.swing.JFrame {

      //usando a variavel conexao de DAL
    Connection conexao = null;
    // criando variavel especial para conexao com o banco
    //Prepared Statement e ResultSet são frameworks do pacote java.sql
    // a servem para preparar e executar as intruções SQL
    PreparedStatement pst = null;
    ResultSet rs = null;
    // Contador para tentativas de login
    private int tentativasFalhas = 0;
    private static final int MAX_TENTATIVAS = 3;
    
public void logar() {
    if (tentativasFalhas >= MAX_TENTATIVAS) {
            //Estilizacao.estilizarOptionPaneErro();
            JOptionPane.showMessageDialog(null, "Número máximo de tentativas excedido. Feche o programa.", "Erro", JOptionPane.ERROR_MESSAGE);
            //Estilizacao.estilizarOptionPaneErro();
            txtLogin.setEnabled(false);
            txtSenha.setEnabled(false);
            btnEntrar.setEnabled(false); // Desabilita o botão entrar também
            return; // Sai do método logar() para evitar mais tentativas
        }
    String sql = "SELECT * FROM login_funcionario WHERE login=? AND senha=?";
    try {
        pst = conexao.prepareStatement(sql);
        pst.setString(1, txtLogin.getText());
        String captura = new String(txtSenha.getPassword());
        pst.setString(2, captura);

        // Executa a query
        rs = pst.executeQuery();

        // Se existirem usuário e senha correspondente
        if (rs.next()) {
            // Obtém o login do funcionário do ResultSet
            String loginFuncionario = rs.getString("login");

            // Prepara a query para inserir o log de acesso
            String sqlLog = "INSERT INTO log_acessos (login, data_acesso, horario_acesso) VALUES (?,?,?)";
            PreparedStatement pstLog = null;

            try {
                pstLog = conexao.prepareStatement(sqlLog);
                pstLog.setString(1, loginFuncionario);

                // Obtém a data e hora atual
                Date dataHoraAtual = new Date();
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dataFormatada = formato.format(dataHoraAtual);

                pstLog.setString(2, dataFormatada);
                pstLog.setString(3, dataFormatada);
                pstLog.executeUpdate(); // Executa a inserção no log de acesso

                //Estilizacao.estilizarOptionPaneSucesso();
                JOptionPane.showMessageDialog(null, "Login realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                //Estilizacao.resetarOptionPaneEstilos();

                TelaPrincipal principal = new TelaPrincipal(loginFuncionario);
                principal.setVisible(true);
                this.dispose();

            } catch (SQLException e) {
                    //Estilizacao.estilizarOptionPaneErro();
                    JOptionPane.showMessageDialog(null, "Erro ao fechar PreparedStatement do log: " + e, "Erro", JOptionPane.ERROR_MESSAGE);
                    //Estilizacao.resetarOptionPaneEstilos();
            } finally {
                try {
                    if (pstLog != null) pstLog.close();
                } catch (SQLException e) {
                        //Estilizacao.estilizarOptionPaneErro();
                        JOptionPane.showMessageDialog(null, "Erro ao fechar PreparedStatement do log: " + e, "Erro", JOptionPane.ERROR_MESSAGE);
                        //Estilizacao.resetarOptionPaneEstilos();
                }
            }
        } else {
                //Estilizacao.estilizarOptionPaneErro();
                JOptionPane.showMessageDialog(null, "Usuário ou senha inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
                //Estilizacao.resetarOptionPaneEstilos();
            txtLogin.setText(""); // Limpa o campo de login
            txtSenha.setText(""); // Limpa o campo de senha
            tentativasFalhas++; // Incrementa o contador de tentativas falhas
            if (tentativasFalhas >= MAX_TENTATIVAS) {
                //Estilizacao.estilizarOptionPaneErro();
                JOptionPane.showMessageDialog(null, "Número máximo de tentativas excedido. Feche o programa.", "Erro", JOptionPane.ERROR_MESSAGE);
                //Estilizacao.resetarOptionPaneEstilos();
            txtLogin.setEnabled(false);
            txtSenha.setEnabled(false);
            btnEntrar.setEnabled(false); // Desabilita o botão entrar também
    }
}

    } catch (SQLException e) {
            //Estilizacao.estilizarOptionPaneErro();
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e, "Erro", JOptionPane.ERROR_MESSAGE);
            //Estilizacao.resetarOptionPaneEstilos();
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
        } catch (SQLException e) {
                //Estilizacao.estilizarOptionPaneErro();
                JOptionPane.showMessageDialog(null, "Erro ao fechar recursos: " + e, "Erro", JOptionPane.ERROR_MESSAGE);
                //Estilizacao.resetarOptionPaneEstilos();
        }
    }
}
        
 
    public TelaLogin() {
        initComponents();
        conexao = ModuloConexao.conector();
        aplicarEstilos(); // Chamando o método para aplicar estilos
        // a linha abaixo serve de apoio ao status da conexão
        //System.out.println(conexao);
        if (conexao != null) {
            lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/databaseOK.png")));

        } else {
            lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/databaseERR.png")));

        }
    }
    
private void aplicarEstilos() {
    Estilizacao.estilizarLabelTitulo(jLabel1);
    Estilizacao.estilizarLabelTitulo(jLabel3); // Estilizar jLabel3 como título
    Estilizacao.estilizarLabelPadrao(jLabel5);
    Estilizacao.estilizarTextFieldPadrao(txtLogin);
    Estilizacao.estilizarPasswordFieldPadrao(txtSenha);
    Estilizacao.estilizarBotaoPadrao(btnEntrar);
    this.getContentPane().setBackground(Estilizacao.COR_DE_FUNDO);
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtLogin = new javax.swing.JTextField();
        lblStatus = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnEntrar = new javax.swing.JButton();
        txtSenha = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel1.setText("Login:");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel3.setText("Senha:");

        txtLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLoginActionPerformed(evt);
            }
        });

        lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/databaseERR.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/avante/icones/logo 128x128.jpg"))); // NOI18N

        btnEntrar.setText("Entrar");
        btnEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblStatus)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSenha)
                            .addComponent(txtLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btnEntrar))
                .addGap(26, 26, 26))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(txtLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(lblStatus, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(28, 28, 28)
                        .addComponent(btnEntrar))
                    .addComponent(jLabel5))
                .addContainerGap(99, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(564, 295));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarActionPerformed
        // TODO add your handling code here:
        logar();
    }//GEN-LAST:event_btnEntrarActionPerformed

    private void txtLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLoginActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLoginActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JTextField txtLogin;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
