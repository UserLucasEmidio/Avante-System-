package br.com.avante.Estilizacao;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.JDialog;

public class Estilizacao {

    // Cores
    public static final Color COR_PRIMARIA = new Color(52, 152, 219);
    public static final Color COR_DE_FUNDO = new Color(240, 240, 240);
    public static final Color COR_TEXTO_PADRAO = Color.DARK_GRAY;
    public static final Color COR_TEXTO_CAMPO = new Color(150, 150, 150);
    public static final Color COR_DESTAQUE = new Color(231, 76, 60);
    public static final Color COR_BORDA = new Color(200, 200, 200);
    public static final Color COR_ERRO = new Color(255, 99, 71); // Vermelho mais vivo para erros
    public static final Color COR_AVISO = new Color(255, 204, 0); // Amarelo para avisos
    public static final Color COR_SUCESSO = new Color(46, 204, 113);

    // Fontes
    public static final Font FONTE_TITULO = new Font("Arial", Font.BOLD, 15);
    public static final Font FONTE_TEXTO = new Font("Tahoma", Font.PLAIN, 14);
    public static final Font FONTE_LABEL = new Font("Tahoma", Font.BOLD, 12);
    public static Object COR_BOTAO_PADRAO;


    // Estilos de Botão
    public static void estilizarBotaoPadrao(JButton botao) {
        botao.setBackground(COR_PRIMARIA);
        botao.setForeground(Color.WHITE);
        botao.setFont(FONTE_TEXTO);
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
    }

    public static void estilizarBotaoDestaque(JButton botao) {
        estilizarBotaoPadrao(botao);
        botao.setBackground(COR_DESTAQUE);
    }

    // Estilos de TextField
    public static void estilizarTextFieldPadrao(JTextField textField) {
        textField.setBackground(Color.WHITE);
        textField.setForeground(COR_TEXTO_CAMPO);
        textField.setFont(FONTE_TEXTO);
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COR_BORDA),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
    }

    // Estilo para JPasswordField (igual ao JTextField)
    public static void estilizarPasswordFieldPadrao(JPasswordField passwordField) {
        passwordField.setBackground(Color.WHITE);
        passwordField.setForeground(COR_TEXTO_CAMPO);
        passwordField.setFont(FONTE_TEXTO);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COR_BORDA),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
    }

    // Estilos de Label
    public static void estilizarLabelTitulo(JLabel label) {
        label.setForeground(COR_PRIMARIA);
        label.setFont(FONTE_TITULO);
    }

    public static void estilizarLabelPadrao(JLabel label) {
        label.setForeground(COR_TEXTO_PADRAO);
        label.setFont(FONTE_LABEL);
    }

    // Novo método para labels de erro
    public static void estilizarLabelErro(JLabel label) {

    }

    // Novo método para labels de aviso
    public static void estilizarLabelAviso(JLabel label) {

    }

     // Novo método para labels de sucesso
    public static void estilizarLabelSucesso(JLabel label) {
        label.setForeground(COR_SUCESSO);
        label.setFont(FONTE_TEXTO);
        label.setBackground(Color.WHITE);
        label.setOpaque(true);
    }

    // Estilos de ComboBox
    public static void estilizarComboBoxPadrao(JComboBox<?> comboBox) {
        comboBox.setBackground(Color.WHITE);
        comboBox.setForeground(COR_TEXTO_PADRAO);
        comboBox.setFont(FONTE_TEXTO);
        comboBox.setBorder(BorderFactory.createLineBorder(COR_BORDA));
    }

    // Estilos de Tabela
    public static void estilizarTabelaPadrao(JTable tabela) {
        tabela.setFont(FONTE_TEXTO);
        tabela.getTableHeader().setFont(FONTE_LABEL);
        tabela.setGridColor(COR_BORDA);

        // Cores de fundo e fonte
        tabela.setBackground(Color.WHITE);
        tabela.setForeground(Color.BLACK);

        // Cor de fundo do cabeçalho
        tabela.getTableHeader().setBackground(new Color(200, 200, 200));
        tabela.getTableHeader().setForeground(Color.BLACK);

        tabela.setSelectionBackground(new Color(240, 240, 240));
        tabela.setRowHeight(25);
        tabela.setShowGrid(true);
        tabela.getTableHeader().setReorderingAllowed(false);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    }

    public static void estilizarScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(BorderFactory.createLineBorder(COR_BORDA));
    }

    // Método para aplicar estilo a vários componentes de uma vez
    public static void aplicarEstilo(JComponent... componentes) {
        for (JComponent componente : componentes) {
            if (componente instanceof JLabel) {
                estilizarLabelPadrao((JLabel) componente);
            } else if (componente instanceof JTextField) {
                estilizarTextFieldPadrao((JTextField) componente);
            } else if (componente instanceof JPasswordField) {
                estilizarPasswordFieldPadrao((JPasswordField) componente);
            } else if (componente instanceof JButton) {
                estilizarBotaoPadrao((JButton) componente);
            } else if (componente instanceof JComboBox) {
                estilizarComboBoxPadrao((JComboBox<?>) componente);
            } else if (componente instanceof JTable) {
                estilizarTabelaPadrao((JTable) componente);
            } else if (componente instanceof JScrollPane) {
                estilizarScrollPane((JScrollPane) componente);
            }
            // Adicione outros tipos de componentes conforme necessário
        }
    }

    public static void estilizarMenu(JMenu btnAgenda) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static void estilizarMenuItem(JMenuItem menAgenda) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static void estilizarLabelFuncionarioLogado(JLabel jLabel2) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // Métodos para estilizar JOptionPane globalmente
    /*public static void estilizarOptionPaneErro() {
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
        UIManager.put("OptionPane.messageForeground", COR_ERRO);
        UIManager.put("OptionPane.messageFont", FONTE_TEXTO);
        UIManager.put("OptionPane.buttonFont", FONTE_TEXTO); // Estiliza a fonte dos botões
    }
*/
    /*public static void estilizarOptionPaneAviso() {
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
        UIManager.put("OptionPane.messageForeground", COR_AVISO);
        UIManager.put("OptionPane.messageFont", FONTE_TEXTO);
        UIManager.put("OptionPane.buttonFont", FONTE_TEXTO);
    }
*/
     /*
        public static void estilizarOptionPaneSucesso() {
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
        UIManager.put("OptionPane.messageForeground", COR_SUCESSO);
        UIManager.put("OptionPane.messageFont", FONTE_TEXTO);
        UIManager.put("OptionPane.buttonFont", FONTE_TEXTO);
    }
    */
    public static void resetarOptionPaneEstilos() {
        UIManager.put("OptionPane.background", UIManager.get("OptionPane.background"));
        UIManager.put("Panel.background", UIManager.get("Panel.background"));
        UIManager.put("OptionPane.messageForeground", UIManager.get("OptionPane.messageForeground"));
        UIManager.put("OptionPane.messageFont", UIManager.get("OptionPane.messageFont"));
        UIManager.put("OptionPane.buttonFont",  UIManager.get("OptionPane.buttonFont"));
    }
}
