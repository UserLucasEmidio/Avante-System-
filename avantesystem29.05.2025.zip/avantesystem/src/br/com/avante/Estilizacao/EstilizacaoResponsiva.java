import java.awt.Component;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.awt.Color;
import javax.swing.UIManager;

public class EstilizacaoResponsiva {

    private static float escalaLargura = 1.0f;
    private static float escalaAltura = 1.0f;

    // Método para calcular as escalas com base na resolução
    public static void calcularEscalas(int larguraBase, int alturaBase, int larguraAtual, int alturaAtual) {
        escalaLargura = (float) larguraAtual / larguraBase;
        escalaAltura = (float) alturaAtual / alturaBase;
    }

    // Métodos para aplicar estilos e tornar componentes responsivos
    public static void estilizarLabelTitulo(JLabel label) {
        if (label != null) {
            Font fonte = label.getFont();
            label.setFont(fonte.deriveFont(Font.BOLD, fonte.getSize() * escalaAltura));
            label.setForeground(new Color(255, 255, 255));
        }
    }

    public static void estilizarLabelPadrao(JLabel label) {
        if (label != null) {
            Font fonte = label.getFont();
            label.setFont(fonte.deriveFont(fonte.getSize() * escalaAltura));
            label.setForeground(new Color(255, 255, 255));
        }
    }

    public static void estilizarTextFieldPadrao(JTextField textField) {
        if (textField != null) {
            Font fonte = textField.getFont();
            textField.setFont(fonte.deriveFont(fonte.getSize() * escalaAltura));
             textField.setBackground(new Color(255, 255, 255));
            textField.setForeground(new Color(0, 0, 0));
        }
    }

    public static void estilizarBotaoPadrao(JButton button) {
        if (button != null) {
            Font fonte = button.getFont();
            button.setFont(fonte.deriveFont(Font.BOLD, fonte.getSize() * escalaAltura));
            button.setBackground(new Color(50, 205, 50));
            button.setForeground(new Color(255, 255, 255));
        }
    }

    public static void estilizarComboBoxPadrao(JComboBox<?> comboBox) {
        if (comboBox != null) {
            Font fonte = comboBox.getFont();
            comboBox.setFont(fonte.deriveFont(fonte.getSize() * escalaAltura));
            comboBox.setBackground(new Color(255, 255, 255));
            comboBox.setForeground(new Color(0, 0, 0));
        }
    }

    public static void estilizarTabelaPadrao(JTable table) {
        if (table != null) {
            Font fonte = table.getFont();
            table.getTableHeader().setFont(fonte.deriveFont(Font.BOLD, fonte.getSize() * escalaAltura));
            table.setFont(fonte.deriveFont(fonte.getSize() * escalaAltura));
             table.setBackground(new Color(255, 255, 255));
            table.setForeground(new Color(0, 0, 0));
        }
    }

    public static void estilizarScrollPane(JScrollPane scrollPane) {
        if (scrollPane != null) {
             scrollPane.setBackground(new Color(0, 128, 0));
            scrollPane.setForeground(new Color(255, 255, 255));
        }
    }

    public static void estilizarJInternalFrame(JInternalFrame internalFrame) {
        if (internalFrame != null) {
            internalFrame.getContentPane().setBackground(new Color(0, 128, 0));
        }
    }

    public static void estilizarOptionPaneErro() {
        UIManager.put("OptionPane.background", new Color(255, 0, 0));
        UIManager.put("Panel.background", new Color(255, 0, 0));
        UIManager.put("OptionPane.messageForeground", new Color(255, 255, 255));
        UIManager.put("OptionPane.buttonBackground", new Color(100, 100, 100));
        UIManager.put("OptionPane.buttonForeground", new Color(255, 255, 255));
    }

    public static void estilizarOptionPaneInfo() {
        UIManager.put("OptionPane.background", new Color(0, 128, 0));
        UIManager.put("Panel.background", new Color(0, 128, 0));
        UIManager.put("OptionPane.messageForeground", new Color(255, 255, 255));
        UIManager.put("OptionPane.buttonBackground", new Color(50, 205, 50));
        UIManager.put("OptionPane.buttonForeground", new Color(255, 255, 255));
    }

    // Adicione métodos para outros componentes conforme necessário
    
     public static void aplicarEstilos(Component[] componentes) {
        for (Component componente : componentes) {
            if (componente instanceof JLabel) {
                estilizarLabelPadrao((JLabel) componente);
            } else if (componente instanceof JTextField) {
                estilizarTextFieldPadrao((JTextField) componente);
            } else if (componente instanceof JButton) {
                estilizarBotaoPadrao((JButton) componente);
            } else if (componente instanceof JComboBox) {
                estilizarComboBoxPadrao((JComboBox<?>) componente);
            } else if (componente instanceof JTable) {
                estilizarTabelaPadrao((JTable) componente);
            } else if (componente instanceof JScrollPane) {
                estilizarScrollPane((JScrollPane) componente);
            }
            // Adicione mais verificações para outros tipos de componentes conforme necessário
        }
    }
}